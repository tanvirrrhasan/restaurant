import React from 'react';
import Hero from '../components/Hero';
import FeaturedItems from '../components/FeaturedItems';
import Services from '../components/Services';
import About from '../components/About';

const Home: React.FC = () => {
  return (
    <>
      <Hero />
      
      <About />
      
      {/* Redesigned Premium Featured Items Section */}
      <FeaturedItems />

      <Services />
    </>
  );
};

export default Home;