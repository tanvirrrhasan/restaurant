import React from 'react';
import PageHeader from '../components/ui/PageHeader';
import Services from '../components/Services';

const ServicesPage: React.FC = () => {
  return (
    <div>
      <PageHeader 
        title="আমাদের সার্ভিসসমূহ" 
        subtitle="আমরা শুধু খাবারই পরিবেশন করি না। আমাদের টপ-নচ ক্যাটারিং, দ্রুত ডেলিভারি এবং ইভেন্ট ম্যানেজমেন্টের অভিজ্ঞতা নিন।"
        image="https://images.unsplash.com/photo-1555244162-803834f70033?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80"
      />
      <Services />
    </div>
  );
};

export default ServicesPage;