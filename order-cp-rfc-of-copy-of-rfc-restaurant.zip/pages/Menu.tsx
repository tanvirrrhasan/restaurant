
import React, { useState, useEffect, useRef } from 'react';
import { 
  Search, 
  ShoppingBag, 
  X, 
  Minus, 
  Plus, 
  MapPin, 
  Phone, 
  User, 
  CheckCircle,
  UtensilsCrossed,
  Coffee,
  Soup,
  IceCream,
  Sparkles,
  Pizza,
  ArrowLeft,
  Loader2,
  Flame,
  ChefHat,
  CupSoda
} from 'lucide-react';
import { motion, AnimatePresence, useScroll, useMotionValueEvent } from 'framer-motion';
import { MenuItem, MenuCategory } from '../types';
import { Link, useLocation } from 'react-router-dom';

const MenuPage: React.FC = () => {
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [filteredItems, setFilteredItems] = useState<MenuItem[]>([]);
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  
  const [selectedItems, setSelectedItems] = useState<{item: MenuItem, quantity: number}[]>([]);
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
  const [orderSuccess, setOrderSuccess] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');

  const [showSearch, setShowSearch] = useState(true);
  const { scrollY } = useScroll();
  const lastScrollY = useRef(0);
  
  const location = useLocation();

  const TELEGRAM_BOT_TOKEN = '8597551744:AAGuBpjuY-lQJ9ZxfPKrS1Dt2FYndRK_KEM'; 
  const TELEGRAM_CHAT_ID = '6170896703'; 

  // Auto-close modal if cart becomes empty
  useEffect(() => {
    if (selectedItems.length === 0 && isOrderModalOpen) {
      setIsOrderModalOpen(false);
    }
  }, [selectedItems.length, isOrderModalOpen]);

  // Handle incoming selection from Home page
  useEffect(() => {
    if (!loading && menuItems.length > 0 && location.state?.selectedItemId) {
      const targetId = location.state.selectedItemId;
      const targetItem = menuItems.find(i => i.id === targetId);
      
      if (targetItem) {
        // 1. Ensure it's not already selected
        setSelectedItems(prev => {
          if (prev.some(i => i.item.id === targetId)) return prev;
          return [...prev, { item: targetItem, quantity: 1 }];
        });

        // 2. Clear search and set category to All to ensure item is visible
        setSearchQuery('');
        setActiveCategory('All');

        // 3. Scroll to the item with a slight delay to ensure it's rendered
        setTimeout(() => {
          const element = document.getElementById(`menu-item-${targetId}`);
          if (element) {
            element.scrollIntoView({ behavior: 'smooth', block: 'center' });
          }
        }, 300);
      }
    }
  }, [loading, menuItems, location.state]);

  useEffect(() => {
    fetch('data/products.json')
      .then(res => res.json())
      .then(data => {
        setMenuItems(data as MenuItem[]);
        setFilteredItems(data as MenuItem[]);
        setLoading(false);
      })
      .catch(err => console.error("Error loading menu:", err));
  }, []);

  useEffect(() => {
    let result = menuItems;
    if (activeCategory !== 'All') {
      if (activeCategory === MenuCategory.SPECIAL) {
        result = result.filter(item => 
          item.name.toLowerCase().includes('rfc special')
        );
      } else {
        result = result.filter(item => item.category === activeCategory);
      }
    }
    if (searchQuery) {
      result = result.filter(item => item.name.toLowerCase().includes(searchQuery.toLowerCase()));
    }
    setFilteredItems(result);
  }, [activeCategory, searchQuery, menuItems]);

  useMotionValueEvent(scrollY, "change", (latest) => {
    const direction = latest > lastScrollY.current ? "down" : "up";
    if (latest < 10) setShowSearch(true);
    else if (direction === "down" && latest > 50) setShowSearch(false);
    else setShowSearch(true);
    lastScrollY.current = latest;
  });

  const getCategoryIcon = (cat: string) => {
    switch(cat) {
      case MenuCategory.COFFEE: return <Coffee size={18} />;
      case MenuCategory.BURGER: return <Pizza size={18} />;
      case MenuCategory.FRY: return <Flame size={18} />;
      case MenuCategory.DRINKS: return <IceCream size={18} />;
      case MenuCategory.SPECIAL: return <Sparkles size={18} />;
      case MenuCategory.CHINESE: return <UtensilsCrossed size={18} />;
      case MenuCategory.SOUP: return <Soup size={18} />;
      case MenuCategory.BIRYANI: return <ChefHat size={18} />;
      default: return <UtensilsCrossed size={18} />;
    }
  };

  const calculateTotal = () => {
    return selectedItems.reduce((total, i) => {
      const price = parseInt(i.item.price?.replace(/[^\d]/g, '') || '0');
      return total + (price * i.quantity);
    }, 0);
  };

  const handleConfirmOrder = async () => {
    if (!customerName || !customerPhone || !customerAddress) {
      alert("অনুগ্রহ করে সব তথ্য দিন।");
      return;
    }
    setIsSubmitting(true);
    const total = calculateTotal();
    let message = `🛒 *NEW ORDER!* \n\n👤 ${customerName}\n📞 ${customerPhone}\n📍 ${customerAddress}\n\n`;
    selectedItems.forEach(i => message += `• ${i.item.name} x ${i.quantity}\n`);
    message += `\n💰 Total: ${total}/-`;

    try {
      await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: TELEGRAM_CHAT_ID, text: message, parse_mode: 'Markdown' }),
      });
      setOrderSuccess(true);
    } catch (e) { alert("Error sending order."); }
    setIsSubmitting(false);
  };

  return (
    <div className="min-h-screen bg-[#0f0f10] text-white pb-32 relative z-40">
      <motion.div 
        className="fixed top-[64px] left-0 right-0 z-40 bg-black/40 backdrop-blur-xl border-b border-white/10 px-4 py-3 shadow-lg"
        initial={{ y: 0 }}
        animate={{ y: showSearch ? 0 : -100 }}
      >
        <div className="flex items-center gap-2 max-w-2xl mx-auto">
          <Link to="/" className="p-2 bg-gray-800 rounded-full shrink-0"><ArrowLeft size={20} /></Link>
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
            <input 
              type="text" placeholder="খাবার খুঁজুন..." 
              value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-gray-800 border border-gray-700 rounded-full py-2 pl-9 pr-4 text-sm text-white focus:outline-none"
            />
          </div>
          <button onClick={() => selectedItems.length > 0 && setIsOrderModalOpen(true)} className="relative shrink-0">
             <div className="p-2 bg-gray-800 rounded-full text-rfc-gold"><ShoppingBag size={20} /></div>
             {selectedItems.length > 0 && <span className="absolute -top-1 -right-1 bg-rfc-red text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-bold">{selectedItems.length}</span>}
          </button>
        </div>
      </motion.div>

      <div className="pt-[140px] px-4 max-w-2xl mx-auto">
        {loading ? <div className="text-center pt-20 text-rfc-gold">লোড হচ্ছে...</div> : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {filteredItems.map(item => {
              const selected = selectedItems.some(i => i.item.id === item.id);
              const isSpecial = item.name.toLowerCase().includes('rfc special');
              return (
                <motion.div 
                  key={item.id} 
                  id={`menu-item-${item.id}`}
                  layout 
                  onClick={() => {
                    if(selected) setSelectedItems(prev => prev.filter(i => i.item.id !== item.id));
                    else setSelectedItems(prev => [...prev, { item, quantity: 1 }]);
                  }}
                  className={`flex p-2 rounded-xl border cursor-pointer transition-all ${selected ? 'border-rfc-red bg-gray-900 shadow-lg' : 'border-white/5 bg-white/5'}`}
                >
                  <div className="relative w-20 h-20 shrink-0">
                    <img src={item.image} className="w-full h-full rounded-lg object-cover" />
                    {selected && (
                      <div className="absolute inset-0 bg-rfc-red/40 flex items-center justify-center rounded-lg">
                        <CheckCircle className="text-white" size={24} fill="#D90429" />
                      </div>
                    )}
                  </div>
                  <div className="ml-3 flex-1">
                    <div className="flex justify-between items-start">
                      <h3 className="text-sm font-bold line-clamp-1">{item.name}</h3>
                      {(item.popular || isSpecial) && (
                        <span className="text-[8px] bg-rfc-gold text-black px-1 rounded font-bold">HOT</span>
                      )}
                    </div>
                    <p className="text-[10px] text-gray-500 line-clamp-2 mt-0.5">{item.description}</p>
                    <div className="flex justify-between items-center mt-2">
                      <span className="text-rfc-gold font-bold text-sm">{item.price}</span>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full ${selected ? 'bg-rfc-red text-white' : 'bg-gray-700 text-gray-300'}`}>{selected ? 'Added' : 'Add'}</span>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      <AnimatePresence>
        {selectedItems.length > 0 && !isOrderModalOpen && (
          <motion.div initial={{ y: 100 }} animate={{ y: 0 }} exit={{ y: 100 }} className="fixed bottom-[85px] left-0 right-0 px-4 z-40 max-w-2xl mx-auto">
            <button onClick={() => setIsOrderModalOpen(true)} className="w-full bg-rfc-red rounded-xl p-4 flex justify-between items-center shadow-2xl">
               <div className="text-left">
                 <span className="block font-bold text-white text-base">{selectedItems.length} Items Selected</span>
                 <span className="text-white/70 text-[10px]">Tap to review your order</span>
               </div>
               <span className="bg-white text-rfc-red px-6 py-2 rounded-lg font-bold">Order Now</span>
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="fixed bottom-0 left-0 right-0 bg-[#0f0f10]/95 backdrop-blur-md border-t border-white/10 z-50 h-[75px]">
        <div className="flex h-full items-center">
          <button 
            onClick={() => setActiveCategory('All')}
            className={`flex flex-col items-center justify-center w-[55px] h-full shrink-0 ${activeCategory === 'All' ? 'text-rfc-gold' : 'text-gray-500'}`}
          >
            <UtensilsCrossed size={18} />
            <span className="text-[8px] mt-1">All</span>
          </button>
          <div className="flex-1 overflow-x-auto no-scrollbar flex items-center h-full gap-0.5 px-1">
            {Object.values(MenuCategory).map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`flex flex-col items-center justify-center min-w-[62px] h-[85%] rounded-lg shrink-0 ${activeCategory === cat ? 'text-rfc-gold bg-white/5' : 'text-gray-500'}`}
              >
                <div className="mb-0.5">{getCategoryIcon(cat)}</div>
                <span className="text-[8px] font-medium whitespace-nowrap overflow-hidden">
                   {cat.split(' ')[0]}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isOrderModalOpen && (
          <div className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/80" onClick={() => !isSubmitting && setIsOrderModalOpen(false)} />
            <motion.div initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }} className="relative bg-[#1a1a1a] w-full max-w-lg rounded-t-3xl p-5 flex flex-col max-h-[90vh]">
              <div className="flex justify-between items-center mb-5 border-b border-white/5 pb-4">
                 <h2 className="text-xl font-bold font-serif">আপনার অর্ডার</h2>
                 {!orderSuccess && <button onClick={() => setIsOrderModalOpen(false)} className="p-2 bg-gray-800 rounded-full"><X size={20} /></button>}
              </div>
              {orderSuccess ? (
                <div className="py-10 text-center">
                  <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-5"><CheckCircle size={32} /></div>
                  <h3 className="text-xl font-bold mb-2">অর্ডার সফল!</h3>
                  <p className="text-gray-400 mb-8">আমরা শীঘ্রই আপনাকে কল করছি।</p>
                  <button onClick={() => { setOrderSuccess(false); setSelectedItems([]); setIsOrderModalOpen(false); }} className="w-full bg-gray-800 py-3 rounded-xl font-bold">Close</button>
                </div>
              ) : (
                <>
                  <div className="flex-1 overflow-y-auto space-y-3 pr-1">
                    {selectedItems.map((cartItem) => (
                      <div key={cartItem.item.id} className="flex gap-3 bg-white/5 p-3 rounded-xl border border-white/5">
                        <img src={cartItem.item.image} className="w-14 h-14 rounded-lg object-cover bg-gray-800" />
                        <div className="flex-1">
                          <div className="flex justify-between items-start">
                            <h4 className="font-bold text-sm">{cartItem.item.name}</h4>
                            <span className="text-rfc-gold font-bold">{cartItem.item.price}</span>
                          </div>
                          <div className="flex items-center gap-3 mt-2">
                            <button onClick={() => setSelectedItems(prev => prev.filter(i => i.item.id !== cartItem.item.id))} className="text-[10px] text-gray-500 underline hover:text-red-400 transition-colors">Remove</button>
                            <div className="ml-auto flex items-center gap-3 bg-gray-800 rounded-lg px-2 py-1">
                              <button onClick={() => setSelectedItems(prev => prev.map(i => i.item.id === cartItem.item.id ? {...i, quantity: Math.max(1, i.quantity - 1)} : i))} className="text-gray-400 hover:text-white"><Minus size={12} /></button>
                              <span className="text-xs font-bold w-4 text-center">{cartItem.quantity}</span>
                              <button onClick={() => setSelectedItems(prev => prev.map(i => i.item.id === cartItem.item.id ? {...i, quantity: i.quantity + 1} : i))} className="text-gray-400 hover:text-white"><Plus size={12} /></button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                    <div className="mt-6 space-y-3 pt-4 border-t border-white/5">
                       <h4 className="text-[10px] uppercase tracking-widest text-gray-500 font-bold">Delivery Details</h4>
                       <div className="relative">
                         <User size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                         <input type="text" value={customerName} onChange={e => setCustomerName(e.target.value)} placeholder="আপনার নাম" className="w-full bg-gray-800/50 rounded-lg p-3 pl-10 text-sm focus:outline-none focus:ring-1 focus:ring-rfc-red" />
                       </div>
                       <div className="relative">
                         <Phone size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                         <input type="tel" value={customerPhone} onChange={e => setCustomerPhone(e.target.value)} placeholder="মোবাইল নম্বর" className="w-full bg-gray-800/50 rounded-lg p-3 pl-10 text-sm focus:outline-none focus:ring-1 focus:ring-rfc-red" />
                       </div>
                       <div className="relative">
                         <MapPin size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                         <input type="text" value={customerAddress} onChange={e => setCustomerAddress(e.target.value)} placeholder="ঠিকানা (এলাকা/রোড)" className="w-full bg-gray-800/50 rounded-lg p-3 pl-10 text-sm focus:outline-none focus:ring-1 focus:ring-rfc-red" />
                       </div>
                    </div>
                  </div>
                  <div className="mt-5 pt-4 border-t border-white/10">
                    <div className="flex justify-between items-center mb-4 px-2">
                       <span className="text-gray-400 text-sm">Total Amount</span>
                       <span className="text-2xl font-bold text-rfc-gold">{calculateTotal()}/-</span>
                    </div>
                    <button onClick={handleConfirmOrder} disabled={isSubmitting} className="w-full bg-rfc-red hover:bg-red-700 py-4 rounded-xl font-bold transition-all shadow-lg shadow-red-900/20 active:scale-[0.98]">
                      {isSubmitting ? <Loader2 className="animate-spin mx-auto" size={24} /> : "Confirm Order"}
                    </button>
                  </div>
                </>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default MenuPage;
