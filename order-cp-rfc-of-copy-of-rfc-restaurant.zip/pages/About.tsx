import React from 'react';
import PageHeader from '../components/ui/PageHeader';
import About from '../components/About';
import { ScrollReveal } from '../components/ui/ScrollReveal';

const AboutPage: React.FC = () => {
  return (
    <div>
      <PageHeader 
        title="আমাদের সম্পর্কে" 
        subtitle="ঐতিহ্যের সাথে আধুনিক স্বাদের মেলবন্ধন। জেনে নিন আমাদের যাত্রার গল্প।"
        image="https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80"
      />
      
      <About />

      {/* Additional Stats Section for the Page */}
      <section className="py-16 bg-black/30 backdrop-blur-md border-y border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
           <ScrollReveal direction="up">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
                 <div className="p-4">
                    <h4 className="text-4xl font-serif font-bold text-rfc-gold mb-2">5k+</h4>
                    <p className="text-gray-400 text-sm uppercase tracking-wider">Happy Customers</p>
                 </div>
                 <div className="p-4">
                    <h4 className="text-4xl font-serif font-bold text-rfc-gold mb-2">50+</h4>
                    <p className="text-gray-400 text-sm uppercase tracking-wider">Food Items</p>
                 </div>
                 <div className="p-4">
                    <h4 className="text-4xl font-serif font-bold text-rfc-gold mb-2">4+</h4>
                    <p className="text-gray-400 text-sm uppercase tracking-wider">Years Experience</p>
                 </div>
                 <div className="p-4">
                    <h4 className="text-4xl font-serif font-bold text-rfc-gold mb-2">20+</h4>
                    <p className="text-gray-400 text-sm uppercase tracking-wider">Team Members</p>
                 </div>
              </div>
           </ScrollReveal>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;