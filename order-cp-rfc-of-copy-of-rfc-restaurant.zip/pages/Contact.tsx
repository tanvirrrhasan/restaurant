import React from 'react';
import PageHeader from '../components/ui/PageHeader';
import { ScrollReveal } from '../components/ui/ScrollReveal';
import { MapPin, Phone, Mail, Clock, Send } from 'lucide-react';

const ContactPage: React.FC = () => {
  return (
    <div className="min-h-screen">
      <PageHeader 
        title="যোগাযোগ করুন" 
        subtitle="কোনো প্রশ্ন আছে বা টেবিল বুক করতে চান? আমাদের সাথে সরাসরি যোগাযোগ করুন।"
        image="https://images.unsplash.com/photo-1485686531765-ba63b07845a7?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80"
      />
      
      <section className="py-12 md:py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16">
          
          {/* ১. কন্টাক্ট ইনফরমেশন সেকশন - এখান থেকে আপনার তথ্য পরিবর্তন করুন */}
          <ScrollReveal direction="right" width="100%">
            <div className="h-full">
              <h2 className="text-3xl font-serif font-bold text-white mb-8">Get In Touch</h2>
              <p className="text-gray-400 mb-8">
                আমরা সবসময় আপনার সেবায় প্রস্তুত। হোম ডেলিভারি, ডাইন-ইন বা ইভেন্ট বুকিংয়ের জন্য আমাদের কল করুন।
              </p>
              
              <div className="space-y-6 md:space-y-8">
                {/* ঠিকানা পরিবর্তন করুন */}
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-white/5 backdrop-blur-sm rounded-full flex items-center justify-center shrink-0 text-rfc-red border border-white/10">
                    <MapPin size={24} />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-white">আমাদের ঠিকানা</h4>
                    <p className="text-gray-400 mt-1">
                      পুরাতন পালকি সিনেমা হলের সামনে,<br />
                      নিয়ামতপুর, নওগাঁ
                    </p>
                  </div>
                </div>

                {/* ফোন নম্বর পরিবর্তন করুন */}
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-white/5 backdrop-blur-sm rounded-full flex items-center justify-center shrink-0 text-rfc-red border border-white/10">
                    <Phone size={24} />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-white">কল করুন</h4>
                    <div className="mt-1">
                      <a href="tel:01717444677" className="block text-gray-400 hover:text-rfc-red transition-colors">01717-444677</a>
                      <a href="tel:01766328123" className="block text-gray-400 hover:text-rfc-red transition-colors">01766-328123</a>
                    </div>
                  </div>
                </div>

                {/* সময় পরিবর্তন করুন */}
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-white/5 backdrop-blur-sm rounded-full flex items-center justify-center shrink-0 text-rfc-red border border-white/10">
                    <Clock size={24} />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-white">খোলার সময়</h4>
                    <div className="mt-1">
                      <p className="text-gray-400">প্রতিদিন: সকাল ১০টা - রাত ১০টা</p>
                      <p className="text-rfc-gold text-sm font-medium mt-1">ছুটির দিনেও খোলা থাকে</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </ScrollReveal>

          {/* কন্টাক্ট ফর্ম */}
          <ScrollReveal direction="left" delay={0.2} width="100%">
            <div className="bg-gray-900/30 backdrop-blur-md p-6 md:p-8 rounded-2xl border border-white/10 h-full">
              <h3 className="text-2xl font-bold text-white mb-6">মেসেজ পাঠান</h3>
              <form className="space-y-5" onSubmit={(e) => e.preventDefault()}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div className="w-full">
                    <label className="block text-sm font-medium text-gray-400 mb-2">আপনার নাম</label>
                    <input 
                      type="text" 
                      className="w-full bg-black/40 border border-gray-700/50 rounded-xl px-4 py-3.5 text-white focus:outline-none focus:ring-2 focus:ring-rfc-red/50 focus:border-rfc-red transition-all placeholder-gray-600" 
                      placeholder="আপনার নাম লিখুন" 
                    />
                  </div>
                  <div className="w-full">
                    <label className="block text-sm font-medium text-gray-400 mb-2">মোবাইল নম্বর</label>
                    <input 
                      type="tel" 
                      className="w-full bg-black/40 border border-gray-700/50 rounded-xl px-4 py-3.5 text-white focus:outline-none focus:ring-2 focus:ring-rfc-red/50 focus:border-rfc-red transition-all placeholder-gray-600" 
                      placeholder="017XXXXXXXX" 
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">মেসেজ</label>
                  <textarea 
                    rows={5} 
                    className="w-full bg-black/40 border border-gray-700/50 rounded-xl px-4 py-3.5 text-white focus:outline-none focus:ring-2 focus:ring-rfc-red/50 focus:border-rfc-red transition-all placeholder-gray-600 resize-none" 
                    placeholder="আপনার বার্তা এখানে লিখুন..."
                  ></textarea>
                </div>
                <button className="w-full bg-rfc-red hover:bg-red-700 text-white font-bold py-4 rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-red-900/30 active:scale-[0.98]">
                  Send Message <Send size={18} />
                </button>
              </form>
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* ২. গুগল ম্যাপ সেকশন - নিচের src এর ভেতরের লিঙ্কটি আপনার ম্যাপ লিঙ্ক দিয়ে পরিবর্তন করুন */}
      <div className="w-full h-80 md:h-[500px] bg-gray-800 border-t border-white/5">
        <iframe 
          src="https://www.google.com/maps/embed?pb=!4v1767649542433!6m8!1m7!1sqUMbN4rqwlVcB2PjUlheTg!2m2!1d24.83385678182328!2d88.57426495977637!3f102.36134259935986!4f31.606738914266543!5f0.7820865974627469" 
          width="100%" 
          height="100%" 
          style={{ border: 0, filter: 'grayscale(00%) invert(0%) contrast(83%)' }} 
          allowFullScreen={true} 
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          title="RFC Restaurant Location"
        ></iframe>
      </div>
    </div>
  );
};

export default ContactPage;