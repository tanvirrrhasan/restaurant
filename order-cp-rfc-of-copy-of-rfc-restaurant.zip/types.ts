import React from 'react';

export interface MenuItem {
  id: string;
  name: string;
  price?: string;
  description?: string;
  category: MenuCategory | string;
  image?: string;
  popular?: boolean;
}

export enum MenuCategory {
  COFFEE = 'Coffee',
  BURGER = 'Burger & Pizza',
  FRY = 'Fry',
  DRINKS = 'Drinks & Faluda',
  SPECIAL = 'RFC Special',
  CHINESE = 'Chinese & Noodles',
  SOUP = 'Soup',
  BIRYANI = 'Biryani'
}

export interface ServiceItem {
  title: string;
  description: string;
  icon: React.ReactNode;
}