import React, { useRef } from 'react';
import { motion, useInView, Variants } from 'framer-motion';

interface ScrollRevealProps {
  children: React.ReactNode;
  width?: "fit-content" | "100%";
  delay?: number;
  direction?: "up" | "down" | "left" | "right";
}

export const ScrollReveal: React.FC<ScrollRevealProps> = ({ 
  children, 
  width = "fit-content",
  delay = 0,
  direction = "up"
}) => {
  const ref = useRef(null);
  // once: false ensures animation happens every time we scroll past it
  const isInView = useInView(ref, { once: false, amount: 0.2 });

  const getDirectionVariants = (): Variants => {
    const distance = 50;
    let initialX = 0;
    let initialY = 0;

    switch (direction) {
      case "up": initialY = distance; break;
      case "down": initialY = -distance; break;
      case "left": initialX = distance; break;
      case "right": initialX = -distance; break;
    }

    return {
      hidden: { opacity: 0, x: initialX, y: initialY },
      visible: { opacity: 1, x: 0, y: 0 }
    };
  };

  return (
    <motion.div
      ref={ref}
      variants={getDirectionVariants()}
      initial="hidden"
      animate={isInView ? "visible" : "hidden"}
      transition={{ duration: 0.6, delay: delay, ease: "easeOut" }}
      style={{ width, position: 'relative' }}
    >
      {children}
    </motion.div>
  );
};

// A variation for stagger effects on lists
export const StaggerContainer: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className }) => {
    const ref = useRef(null);
    const isInView = useInView(ref, { once: false, margin: "-10% 0px -10% 0px" });
  
    return (
      <motion.div
        ref={ref}
        initial="hidden"
        animate={isInView ? "visible" : "hidden"}
        variants={{
          visible: {
            transition: {
              staggerChildren: 0.1
            }
          },
          hidden: {}
        }}
        className={className}
      >
        {children}
      </motion.div>
    );
  };
  
  export const StaggerItem: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className }) => {
    return (
      <motion.div
        variants={{
          hidden: { opacity: 0, y: 30 },
          visible: { opacity: 1, y: 0 }
        }}
        transition={{ duration: 0.5 }}
        className={className}
      >
        {children}
      </motion.div>
    );
  };