import React from 'react';
import { MapPin, Phone, Facebook, Instagram, Clock } from 'lucide-react';
import { ScrollReveal } from './ui/ScrollReveal';

const Footer: React.FC = () => {
  return (
    <footer id="contact" className="bg-black text-gray-300 border-t border-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          
          {/* Brand Info */}
          <ScrollReveal delay={0}>
            <div className="space-y-4">
              <h3 className="text-3xl font-serif font-bold text-white">
                RFC <span className="text-rfc-red text-lg">Restaurant</span>
              </h3>
              <p className="text-sm text-gray-500 leading-relaxed">
                নিয়ামতপুরের চাইনিজ এবং ফাস্ট ফুড প্রেমীদের জন্য প্রিমিয়াম গন্তব্য। স্বাদ, পরিচ্ছন্নতা এবং আতিথেয়তার সেরা অভিজ্ঞতা।
              </p>
              <div className="flex space-x-4 pt-2">
                <a href="#" className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-blue-600 hover:text-white transition-colors">
                  <Facebook size={20} />
                </a>
                <a href="#" className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-pink-600 hover:text-white transition-colors">
                  <Instagram size={20} />
                </a>
              </div>
            </div>
          </ScrollReveal>

          {/* Contact Info - এখানে আপনার তথ্য দিন */}
          <ScrollReveal delay={0.1}>
            <div className="space-y-4">
              <h4 className="text-lg font-bold text-white uppercase tracking-wider mb-4">Contact Us</h4>
              <div className="flex items-start gap-3">
                <MapPin className="text-rfc-red mt-1 shrink-0" size={20} />
                <span>पुराতন পালকি সিনেমা হলের সামনে,<br />নিয়ামতপুর, নওগাঁ</span>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="text-rfc-red shrink-0" size={20} />
                <div className="flex flex-col">
                  <a href="tel:01717444677" className="hover:text-white transition-colors">01717-444677</a>
                  <a href="tel:01766328123" className="hover:text-white transition-colors">01766-328123</a>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Clock className="text-rfc-red shrink-0" size={20} />
                <span>প্রতিদিন: সকাল ১০টা - রাত ১০টা</span>
              </div>
            </div>
          </ScrollReveal>

          {/* Quick Links / Map Placeholder */}
          <ScrollReveal delay={0.2}>
            <div className="space-y-4">
              <h4 className="text-lg font-bold text-white uppercase tracking-wider mb-4">Location</h4>
              <div className="w-full h-48 bg-gray-800 rounded-lg overflow-hidden relative group">
                {/* Mock Map Image */}
                <img 
                  src="https://images.unsplash.com/photo-1524661135-423995f22d0b?auto=format&fit=crop&w=600&q=80" 
                  alt="Map Location" 
                  className="w-full h-full object-cover opacity-50 group-hover:opacity-70 transition-opacity"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                   <a 
                     href="https://maps.google.com" 
                     target="_blank" 
                     rel="noreferrer"
                     className="bg-white text-black px-4 py-2 rounded shadow-lg text-sm font-bold hover:bg-rfc-gold transition-colors"
                   >
                     View on Google Maps
                   </a>
                </div>
              </div>
            </div>
          </ScrollReveal>
        </div>
        
        <div className="border-t border-gray-900 mt-12 pt-8 text-center text-sm text-gray-600">
          <p>&copy; {new Date().getFullYear()} RFC Restaurant. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;