import React, { useState, useEffect } from 'react';
import { ScrollReveal, StaggerContainer, StaggerItem } from './ui/ScrollReveal';
import { MenuCategory, MenuItem } from '../types';
import { Star } from 'lucide-react';

interface MenuSectionProps {
  limit?: number;
  featuredOnly?: boolean;
}

const MenuSection: React.FC<MenuSectionProps> = ({ limit, featuredOnly }) => {
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Fetch data from JSON file instead of importing to avoid module resolution errors in browser environment
    fetch('data/products.json')
      .then(res => res.json())
      .then(data => {
        setMenuItems(data as MenuItem[]);
        setLoading(false);
      })
      .catch(err => {
        console.error("Error loading menu data:", err);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <div className="py-20 flex justify-center items-center">
        <div className="text-rfc-gold text-xl animate-pulse">Loading menu...</div>
      </div>
    );
  }

  // Filter items based on props and active category
  let filteredItems = menuItems;

  if (featuredOnly) {
    filteredItems = filteredItems.filter(item => item.popular);
  } else if (activeCategory !== 'All') {
    filteredItems = filteredItems.filter(item => item.category === activeCategory);
  }

  if (limit) {
    filteredItems = filteredItems.slice(0, limit);
  }

  return (
    <section className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {!featuredOnly && (
          <ScrollReveal direction="up">
            <div className="text-center mb-12">
              <h2 className="text-rfc-red font-bold tracking-widest uppercase mb-2">Our Menu</h2>
              <h3 className="text-4xl md:text-5xl font-serif font-bold text-white">আমাদের সম্পূর্ণ মেনু</h3>
              <p className="text-gray-400 mt-4 max-w-2xl mx-auto">
                হালকা নাস্তা থেকে শুরু করে ভারী খাবার, RFC-তে সব ধরণের স্বাদের সমাহার।
              </p>
            </div>
          </ScrollReveal>
        )}

        {/* Category Tabs (Only show if not featured only) */}
        {!featuredOnly && (
          <ScrollReveal direction="up" delay={0.1}>
            <div className="flex flex-wrap justify-center gap-4 mb-12">
              <button
                onClick={() => setActiveCategory('All')}
                className={`px-6 py-2 rounded-full font-medium transition-all duration-300 ${
                  activeCategory === 'All'
                    ? 'bg-rfc-red text-white shadow-lg scale-105'
                    : 'bg-white/5 backdrop-blur-sm text-gray-300 hover:bg-white/10'
                }`}
              >
                All
              </button>
              
              {Object.values(MenuCategory).map((category) => (
                <button
                  key={category}
                  onClick={() => setActiveCategory(category)}
                  className={`px-6 py-2 rounded-full font-medium transition-all duration-300 ${
                    activeCategory === category
                      ? 'bg-rfc-red text-white shadow-lg scale-105'
                      : 'bg-white/5 backdrop-blur-sm text-gray-300 hover:bg-white/10'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </ScrollReveal>
        )}

        {/* Menu Grid */}
        <StaggerContainer className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredItems.map((item) => (
            <StaggerItem key={item.id} className="h-full">
              <div className="bg-gray-900/40 backdrop-blur-md border border-white/5 rounded-xl overflow-hidden hover:border-rfc-red/50 transition-all duration-300 h-full flex flex-col group hover:shadow-2xl hover:shadow-red-900/10 hover:-translate-y-2">
                <div className="relative h-56 overflow-hidden bg-gray-800/50">
                   {item.image ? (
                     <img 
                      src={item.image} 
                      alt={item.name} 
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" 
                      loading="lazy"
                     />
                   ) : (
                     <div className="w-full h-full bg-gradient-to-br from-gray-800 to-gray-700 flex items-center justify-center">
                        <span className="text-gray-500 text-4xl opacity-20 font-serif">RFC</span>
                     </div>
                   )}
                   {item.popular && (
                     <div className="absolute top-2 right-2 bg-rfc-gold text-black text-xs font-bold px-2 py-1 rounded flex items-center gap-1 z-10">
                       <Star size={12} fill="black" /> POPULAR
                     </div>
                   )}
                   <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors"></div>
                </div>
                
                <div className="p-6 flex-grow flex flex-col">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="text-xl font-bold text-white group-hover:text-rfc-red transition-colors line-clamp-2">{item.name}</h4>
                    <span className="text-rfc-gold font-bold text-lg whitespace-nowrap ml-2">{item.price}</span>
                  </div>
                  <p className="text-gray-400 text-sm mb-4 flex-grow line-clamp-2">{item.description}</p>
                  <button className="w-full py-2 border border-gray-600/50 text-gray-300 rounded-lg hover:bg-rfc-red hover:border-rfc-red hover:text-white transition-colors text-sm font-medium uppercase tracking-wide mt-auto">
                    Add to Order
                  </button>
                </div>
              </div>
            </StaggerItem>
          ))}
        </StaggerContainer>
      </div>
    </section>
  );
};

export default MenuSection;