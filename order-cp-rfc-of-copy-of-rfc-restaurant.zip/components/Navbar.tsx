import React, { useState, useEffect, useRef } from 'react';
import { Menu, X, Phone, ShoppingBag } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link, useLocation } from 'react-router-dom';

interface NavbarProps {
  hidden?: boolean;
}

const Navbar: React.FC<NavbarProps> = ({ hidden = false }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const navRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
      if (isOpen) {
        setIsOpen(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [isOpen]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (isOpen && navRef.current && !navRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'About', path: '/about' },
    { name: 'Menu', path: '/menu' },
    { name: 'Services', path: '/services' },
    { name: 'Contact', path: '/contact' },
  ];

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  const isHome = location.pathname === '/';
  
  const showGlass = scrolled || !isHome || isOpen;

  if (hidden) return null;

  return (
    <nav 
      ref={navRef}
      className={`fixed w-full z-50 transition-all duration-300 ease-in-out ${
        showGlass 
          ? 'bg-black/20 backdrop-blur-xl border-b border-white/10 shadow-lg py-2' 
          : 'bg-transparent py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo - Restored to original full version */}
          <Link to="/" className="flex-shrink-0 flex items-center gap-2 group">
            <motion.div 
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="w-10 h-10 bg-rfc-red rounded-full flex items-center justify-center text-white font-bold font-serif text-xl border-2 border-rfc-gold group-hover:scale-110 transition-transform shadow-lg"
            >
              R
            </motion.div>
            <span className="font-serif font-bold text-2xl text-white tracking-wider drop-shadow-md">
              RFC <span className="text-rfc-red text-lg font-sans font-normal">Restaurant</span>
            </span>
          </Link>

          {/* Desktop Menu - Specifically narrowed only for tablets (md) */}
          <div className="hidden md:block">
            <div className="ml-4 lg:ml-10 flex items-baseline space-x-2 lg:space-x-8">
              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.path}
                  className={`px-2 lg:px-3 py-2 rounded-md text-sm lg:text-base font-medium transition-colors duration-200 relative group ${
                    isActive(link.path) ? 'text-rfc-gold' : 'text-gray-200 hover:text-rfc-gold'
                  }`}
                >
                  {link.name}
                  <span className={`absolute bottom-0 left-0 h-0.5 bg-rfc-red transition-all duration-300 ${isActive(link.path) ? 'w-full' : 'w-0 group-hover:w-full'}`}></span>
                </Link>
              ))}
            </div>
          </div>

          {/* CTA Button - Spacing adjusted for tablet (md) */}
          <div className="hidden md:flex items-center gap-3 lg:gap-6">
             <a href="tel:01717444677" className="flex items-center gap-2 text-white hover:text-rfc-gold transition-colors whitespace-nowrap">
                <Phone size={18} className="shrink-0" />
                <span className="text-sm lg:text-base font-bold">01717-444677</span>
             </a>
             <Link to="/menu" className="bg-rfc-gold hover:bg-yellow-500 text-black px-4 lg:px-6 py-2.5 rounded-full font-bold text-sm lg:text-base transition-all transform hover:scale-105 shadow-lg shadow-yellow-900/20 flex items-center gap-2 whitespace-nowrap">
               <ShoppingBag size={18} className="shrink-0" /> Order Now
             </Link>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-200 hover:text-white hover:bg-white/10 focus:outline-none transition-colors"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden border-t border-white/10 overflow-hidden"
          >
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              {navLinks.filter(link => link.name !== 'Menu').map((link) => (
                <Link
                  key={link.name}
                  to={link.path}
                  onClick={() => setIsOpen(false)}
                  className={`block px-3 py-2 rounded-md text-base font-medium text-center ${
                    isActive(link.path) 
                      ? 'bg-white/10 text-rfc-gold' 
                      : 'text-gray-300 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {link.name}
                </Link>
              ))}

              <Link
                to="/menu"
                onClick={() => setIsOpen(false)}
                className="block w-full text-center bg-rfc-gold text-black py-3 rounded-md mt-4 font-bold shadow-lg hover:bg-yellow-500 transition-colors uppercase tracking-widest"
              >
                Order Now
              </Link>

              <a href="tel:01717444677" className="block w-full text-center bg-rfc-red text-white py-3 rounded-md mt-3 font-bold shadow-lg hover:bg-red-700 transition-colors">
                 Call To Order
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;