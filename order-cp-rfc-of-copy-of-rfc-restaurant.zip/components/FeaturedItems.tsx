
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ScrollReveal, StaggerContainer, StaggerItem } from './ui/ScrollReveal';
import { MenuItem } from '../types';
import { Star, ArrowRight, ShoppingCart } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';

const FeaturedItems: React.FC = () => {
  const [featuredItems, setFeaturedItems] = useState<MenuItem[]>([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetch('data/products.json')
      .then(res => res.json())
      .then((data: MenuItem[]) => {
        // Find items marked as popular or containing "RFC Special"
        const popular = data.filter(item => item.popular || item.name.toLowerCase().includes('rfc special')).slice(0, 3);
        setFeaturedItems(popular);
      })
      .catch(err => console.error("Error loading featured items:", err));
  }, []);

  const handleOrderNow = (item: MenuItem) => {
    // Navigate to menu page and pass the selected item ID to auto-select and scroll
    navigate('/menu', { state: { selectedItemId: item.id } });
  };

  if (featuredItems.length === 0) return null;

  return (
    <section className="pt-10 pb-10 md:pt-24 md:pb-16 relative overflow-hidden bg-[#0a0a0b]">
      {/* Decorative Background Elements */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-rfc-red/5 rounded-full blur-[120px] -z-10"></div>
      <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-rfc-gold/5 rounded-full blur-[100px] -z-10"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <ScrollReveal direction="down">
            <span className="inline-block py-1 px-4 rounded-full bg-rfc-red/10 border border-rfc-red/20 text-rfc-red text-xs font-bold tracking-widest uppercase mb-4">
              Chef's Recommendation
            </span>
          </ScrollReveal>
          <ScrollReveal>
            <h2 className="text-4xl md:text-6xl font-serif font-bold text-white mb-6">
              জনপ্রিয় <span className="text-rfc-gold">সিগনেচার</span> ডিশ
            </h2>
          </ScrollReveal>
          <ScrollReveal delay={0.2}>
            <p className="text-gray-400 max-w-2xl mx-auto text-lg">
              আমাদের সবচেয়ে বেশি বিক্রিত এবং প্রশংসিত কিছু স্পেশাল খাবার যা আপনার জিভে জল আনতে বাধ্য।
            </p>
          </ScrollReveal>
        </div>

        <StaggerContainer className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {featuredItems.map((item) => (
            <StaggerItem key={item.id}>
              <motion.div 
                whileHover={{ y: -10 }}
                className="relative group bg-[#151516] rounded-[2.5rem] p-4 border border-white/5 hover:border-rfc-red/30 transition-all duration-500 shadow-2xl"
              >
                {/* Image Container */}
                <div className="relative h-72 rounded-[2rem] overflow-hidden mb-6">
                  <img 
                    src={item.image} 
                    alt={item.name} 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
                  
                  {/* Badge */}
                  <div className="absolute top-4 left-4 bg-[#D90429] text-white text-[10px] font-bold px-3 py-1.5 rounded-full flex items-center gap-1 shadow-lg">
                    <Star size={10} fill="white" /> TOP RATED
                  </div>

                  {/* Price Tag - Yellow Tag style like screenshot */}
                  <div className="absolute bottom-4 right-4 bg-rfc-gold text-black px-4 py-2 rounded-xl font-bold text-base shadow-lg">
                    {item.price}
                  </div>
                </div>

                {/* Content */}
                <div className="px-2 pb-4 text-center">
                  <h3 className="text-2xl font-bold text-white mb-2 group-hover:text-rfc-gold transition-colors">
                    {item.name}
                  </h3>
                  <p className="text-gray-400 text-sm mb-6 leading-relaxed">
                    {item.description}
                  </p>
                  
                  <button 
                    onClick={() => handleOrderNow(item)}
                    className="w-full bg-[#D90429] hover:bg-red-700 text-white py-4 rounded-[1.2rem] font-bold flex items-center justify-center gap-2 transition-all active:scale-95 shadow-lg shadow-red-900/20"
                  >
                    <ShoppingCart size={20} /> অর্ডার দিন
                  </button>
                </div>
              </motion.div>
            </StaggerItem>
          ))}
        </StaggerContainer>

        <div className="mt-16 text-center">
          <ScrollReveal delay={0.4}>
            <Link 
              to="/menu" 
              className="inline-flex items-center gap-2 text-rfc-gold md:text-white font-bold text-lg md:hover:text-rfc-gold transition-colors group"
            >
              পুরো মেনু কার্ড দেখুন 
              <span className="w-10 h-10 rounded-full flex items-center justify-center transition-all bg-rfc-gold text-black md:bg-white/5 md:text-white md:group-hover:bg-rfc-gold md:group-hover:text-black">
                <ArrowRight size={20} />
              </span>
            </Link>
          </ScrollReveal>
        </div>
      </div>
    </section>
  );
};

export default FeaturedItems;
