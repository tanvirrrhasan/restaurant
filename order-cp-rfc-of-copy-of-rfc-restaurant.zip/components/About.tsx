import React from 'react';
import { ScrollReveal } from './ui/ScrollReveal';
import { CheckCircle, ChefHat, Heart, Award } from 'lucide-react';
import { Link } from 'react-router-dom';

const About: React.FC = () => {
  return (
    <section className="pt-20 pb-6 md:pb-20 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          
          {/* Image Grid */}
          <ScrollReveal direction="right">
            <div className="relative">
              <div className="grid grid-cols-2 gap-4">
                <img 
                  src="https://images.unsplash.com/photo-1559339352-11d035aa65de?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
                  alt="Restaurant Interior" 
                  className="rounded-2xl shadow-xl w-full h-64 object-cover transform translate-y-8"
                />
                <img 
                  src="https://images.unsplash.com/photo-1581349485608-9469926a8e5e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
                  alt="Delicious Food" 
                  className="rounded-2xl shadow-xl w-full h-64 object-cover"
                />
              </div>
              {/* Decorative Circle */}
              <div className="absolute -z-10 top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-rfc-red/5 rounded-full blur-3xl"></div>
            </div>
          </ScrollReveal>

          {/* Text Content */}
          <ScrollReveal direction="left">
            <div>
              <div className="inline-flex items-center gap-2 border border-rfc-gold/30 px-3 py-1 rounded-full mb-6 backdrop-blur-sm bg-white/5">
                <span className="text-rfc-gold text-xs font-bold uppercase tracking-widest">Since 2020</span>
              </div>
              <h2 className="text-4xl md:text-5xl font-serif font-bold text-white mb-6 leading-tight">
                খাবারের প্রতি ভালোবাসা, <br />
                <span className="text-rfc-red">সেবার প্রতি বিশ্বাস</span>
              </h2>
              <p className="text-gray-400 mb-6 text-lg leading-relaxed">
                RFC রেস্টুরেন্ট শুরু হয়েছিল একটি স্বপ্ন নিয়ে—নিয়ামতপুরের ভোজনরসিকদের জন্য বিশ্বমানের চাইনিজ ও ফাস্ট ফুডের স্বাদ পৌঁছে দেওয়া। আজ আমরা গর্বিত যে, আমাদের প্রতিটি ডিশে আপনারা খুঁজে পান বিশ্বাস এবং ভালোবাসা।
              </p>
              <p className="text-gray-400 mb-8 leading-relaxed">
                পরিচ্ছন্ন পরিবেশ এবং দক্ষ শেফের হাতের জাদুতে আমরা আপনাদের জন্য নিয়ে আসি সেরা স্বাদের নিশ্চয়তা। আমাদের লক্ষ্য শুধুমাত্র খাবার পরিবেশন করা নয়, বরং একটি সুন্দর মুহূর্ত উপহার দেওয়া।
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
                <div className="flex items-center gap-3">
                  <ChefHat className="text-rfc-gold" size={24} />
                  <span className="text-white font-medium">এক্সপার্ট শেফ</span>
                </div>
                <div className="flex items-center gap-3">
                  <Heart className="text-rfc-gold" size={24} />
                  <span className="text-white font-medium">হালাল ও ফ্রেশ</span>
                </div>
                <div className="flex items-center gap-3">
                  <Award className="text-rfc-gold" size={24} />
                  <span className="text-white font-medium">প্রিমিয়াম কোয়ালিটি</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="text-rfc-gold" size={24} />
                  <span className="text-white font-medium">হাইজিন মেইনটেন্ড</span>
                </div>
              </div>

              <Link 
                to="/menu" 
                className="inline-flex items-center justify-center px-8 py-3 bg-rfc-red text-white font-bold rounded-lg hover:bg-red-700 transition-colors shadow-lg shadow-red-900/30"
              >
                Explore Menu
              </Link>
            </div>
          </ScrollReveal>

        </div>
      </div>
    </section>
  );
};

export default About;