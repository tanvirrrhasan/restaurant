import React from 'react';
import { ScrollReveal } from './ui/ScrollReveal';
import { Truck, PartyPopper, CalendarCheck, Utensils } from 'lucide-react';

const Services: React.FC = () => {
  return (
    <section id="services" className="pt-8 pb-20 md:pt-16 md:pb-24 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <ScrollReveal>
          <div className="text-center mb-16">
            <h2 className="text-rfc-red font-bold tracking-widest uppercase mb-2">Our Services</h2>
            <h3 className="text-4xl md:text-5xl font-serif font-bold text-white">শুধু খাবারের চেয়েও বেশি কিছু</h3>
          </div>
        </ScrollReveal>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Home Delivery */}
          <ScrollReveal direction="left">
            <div className="bg-gray-900/30 backdrop-blur-md p-8 rounded-2xl border border-white/5 hover:border-rfc-red transition-all duration-300 flex flex-col md:flex-row gap-6 items-center md:items-start group">
              <div className="bg-white/5 p-4 rounded-full group-hover:bg-rfc-red transition-colors duration-300">
                <Truck size={40} className="text-rfc-gold group-hover:text-white" />
              </div>
              <div className="text-center md:text-left">
                <h4 className="text-2xl font-bold text-white mb-2">দ্রুত হোম ডেলিভারি</h4>
                <p className="text-gray-400 mb-4">
                  বাসায় বসে RFC-এর খাবার খেতে চান? আমরা নিয়ামতপুর এলাকায় ডেলিভারি দিচ্ছি। গরম এবং ফ্রেশ খাবার পৌঁছে যাবে আপনার দরজায়।
                </p>
                <div className="flex items-center justify-center md:justify-start gap-2 text-rfc-gold text-sm font-semibold">
                  <span>Free Delivery Available*</span>
                </div>
              </div>
            </div>
          </ScrollReveal>

          {/* Event Management */}
          <ScrollReveal direction="right" delay={0.2}>
            <div className="bg-gray-900/30 backdrop-blur-md p-8 rounded-2xl border border-white/5 hover:border-rfc-gold transition-all duration-300 flex flex-col md:flex-row gap-6 items-center md:items-start group">
              <div className="bg-white/5 p-4 rounded-full group-hover:bg-rfc-gold transition-colors duration-300">
                <PartyPopper size={40} className="text-rfc-red group-hover:text-black" />
              </div>
              <div className="text-center md:text-left">
                <h4 className="text-2xl font-bold text-white mb-2">ইভেন্ট ক্যাটারিং ও বুকিং</h4>
                <p className="text-gray-400 mb-4">
                  জন্মদিন বা কোনো অনুষ্ঠানের পরিকল্পনা করছেন? আমরা সব ব্যবস্থা করছি! ভেন্যু বুকিং থেকে শুরু করে খাবার পরিবেশন, সব আমাদের ওপর ছেড়ে দিন।
                </p>
                <ul className="text-sm text-gray-500 space-y-1 text-left inline-block">
                  <li className="flex items-center gap-2"><CalendarCheck size={14} className="text-rfc-red"/> Full Event Management</li>
                  <li className="flex items-center gap-2"><Utensils size={14} className="text-rfc-red"/> Custom Bulk Menus</li>
                </ul>
              </div>
            </div>
          </ScrollReveal>
        </div>
        
        {/* Booking CTA */}
        <ScrollReveal direction="up" delay={0.4}>
          <div className="mt-16 bg-gradient-to-r from-rfc-red/90 to-red-900/90 backdrop-blur-md rounded-3xl p-10 text-center relative overflow-hidden shadow-2xl border border-white/10">
             <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
             <h3 className="text-3xl font-serif font-bold text-white mb-4 relative z-10">ইভেন্ট বুক করতে চান?</h3>
             <p className="text-red-100 mb-8 max-w-xl mx-auto relative z-10">
               আপনার পছন্দের মেনু এবং ইভেন্ট নিয়ে কথা বলতে আমাদের সরাসরি কল করুন। আপনার আনন্দই আমাদের লক্ষ্য।
             </p>
             <a href="tel:01717444677" className="relative z-10 inline-flex items-center gap-2 bg-white text-rfc-red px-8 py-3 rounded-full font-bold hover:bg-gray-100 transition-colors">
               <PhoneIcon /> Call 01717-444677
             </a>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
};

const PhoneIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
)

export default Services;