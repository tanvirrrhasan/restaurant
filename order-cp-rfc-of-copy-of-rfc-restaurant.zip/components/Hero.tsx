import React from 'react';
import { ScrollReveal } from './ui/ScrollReveal';
import { ArrowRight, UtensilsCrossed } from 'lucide-react';
import { Link } from 'react-router-dom';

const Hero: React.FC = () => {
  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80" 
          alt="Restaurant Ambiance" 
          className="w-full h-full object-cover"
        />
        {/* Gradient Overlay - Smooth transition to base color */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-[#0f0f10]"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <ScrollReveal direction="down">
          <div className="inline-flex items-center gap-2 border border-rfc-gold/30 bg-black/40 backdrop-blur-sm px-4 py-1.5 rounded-full mb-6">
            <UtensilsCrossed size={16} className="text-rfc-gold" />
            <span className="text-rfc-gold text-sm uppercase tracking-widest font-semibold">Premium Taste</span>
          </div>
        </ScrollReveal>

        <ScrollReveal>
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-serif font-bold text-white mb-6 leading-tight">
            Taste the <span className="text-transparent bg-clip-text bg-gradient-to-r from-rfc-red to-orange-500">Legendary</span> <br />
            RFC Flavors
          </h1>
        </ScrollReveal>

        <ScrollReveal delay={0.2}>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-300 mb-10 font-light">
            নিয়ামতপুরের সেরা চাইনিজ এবং ফাস্ট ফুডের স্বাদ নিন। সিজলিং স্টেক থেকে শুরু করে ক্রিস্পি ফ্রাই, 
            আমরা প্রতিটি প্লেটে আনন্দ পরিবেশন করি।
          </p>
        </ScrollReveal>

        <ScrollReveal delay={0.4}>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link 
              to="/menu" 
              className="px-8 py-4 bg-rfc-red text-white rounded-full font-bold text-lg hover:bg-red-700 transition-all transform hover:scale-105 hover:shadow-[0_0_20px_rgba(217,4,41,0.5)] flex items-center gap-2"
            >
              View Full Menu <ArrowRight size={20} />
            </Link>
            <Link 
              to="/contact" 
              className="px-8 py-4 bg-transparent border-2 border-white text-white rounded-full font-bold text-lg hover:bg-white hover:text-rfc-dark transition-all"
            >
              Book For Event
            </Link>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
};

export default Hero;